<?php
header("Access-Control-Allow-Origin: *");
header('Content-type: application/json');

ini_set("display_errors", 1);
error_reporting(E_ALL);

$json = file_get_contents('php://input'); 
$request = json_decode($json, true);


include_once "gia-bot-api.php";

$api_obj = new GiaBotAPI();


$api_obj->api_request['query'] = $request['query'];
$api_obj->api_request['lang'] = "en";
$api_obj->api_request['sessionId'] = $request['sessionId'];


if(isset($request['akey']))
	$api_obj->accessToken = $request['akey'];
else
{
	$settings = file_get_contents("settings.json");
	$json_settings = json_decode($settings, true);
	$api_obj->accessToken = $json_settings['akey'];
}

$api_obj->assign_default_values();


$response = $api_obj->make_AI_API_Call();


$response_json = array();

if(isset($response['reply_text']))
	$response_json["reply_text"] = $response['reply_text'];

if(isset($response['speech']))
{
	$response['speech'] = str_replace("INV#", "Invoice Number", $response['speech']);
	$response['speech'] = str_replace(" | ", ",", $response['speech']);

	$response_json["speech"] = $response['speech'];
}

if(isset($response['data']))
	$response_json["data"] = $response['data'];

if(isset($response['request']))
	$response_json["request"] = $response['request'];

if(isset($response['contextOut']))
	$response_json["contextOut"] = $response['contextOut'];

echo json_encode($response_json);
?>