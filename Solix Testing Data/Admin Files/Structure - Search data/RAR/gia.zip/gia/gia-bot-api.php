<?php


class GiaBotAPI
{

	var $accessToken, $apiURL, $api_response, $api_request, $no_customer_text, $any_help_text;
	public function __constructor()
	{
		$this->accessToken = "";
		$this->apiURL="https://api.api.ai/v1/";

		$this->api_request = array();

		$this->api_response = array();
		$this->conn = null;

		$this->customer_id='';
		$this->db_customer_name='';
		$this->customer_names = array();

		$this->assign_default_values();
	}

	public function assign_default_values()
	{
		$this->apiURL="https://api.api.ai/v1/";
		if(empty($this->accessToken))
			$this->accessToken = "5d358a7066e44e459e0d5cb276331d76";//gia@emagia.com

		$this->any_help_text = '\n May I help you with anything else?';
		$this->no_customer_text = "I am not able to find any customer with that name. Please check again and give me the exact business name of the customer.";
	}


	public function make_AI_API_Call()
	{		
		$ch = curl_init();
        curl_setopt( $ch, CURLOPT_URL, $this->apiURL."query?v=20150910");
        curl_setopt( $ch, CURLOPT_POST, 1);
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 ); //return transfer
        curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode($this->api_request));
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json', 'charset:utf-8', 'Authorization:Bearer '.$this->accessToken));
        //curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        //echo json_encode($this->api_request);
        $curl_response = curl_exec( $ch );
        $ginfo = curl_getinfo($ch);
        //print_r($ginfo);
        curl_close( $ch );

        $this->API_AI_Processing($curl_response);

		return $this->api_response;
	}


	public function API_AI_Processing($curl_response)
	{
		$response = json_decode($curl_response,true);
		if(isset($response['result']['fulfillment']['displayText']) && !empty($response['result']['fulfillment']['displayText']))
			$this->api_response['reply_text'] = $response['result']['fulfillment']['displayText'];
		else if(isset($response['result']['fulfillment']['speech']) && !empty($response['result']['fulfillment']['speech']))
			$this->api_response['reply_text'] = $response['result']['fulfillment']['speech'];

		if(isset($response['result']['fulfillment']['data']))
			$this->api_response['data'] = $response['result']['fulfillment']['data'];

		if(isset($response['result']['fulfillment']['contextOut']))
			$this->api_response['contextOut'] = $response['result']['fulfillment']['contextOut'];	
	}

	public function API_AI_Context_mapping($contexts,$current_context,$clear=false)
	{
		$context_out = array();
		if(count($contexts))
		{
			foreach ($contexts as $e_key => $each_context) {
				
				if(stripos($each_context['name'], $current_context) === false)
					array_push($context_out, array("name"=> $each_context['name'], "lifespan"=>0));
				else if($clear && stripos($each_context['name'], "followup") === false)
					array_push($context_out, array("name"=> $each_context['name'], "lifespan"=>0));
				else if($clear && stripos($each_context['name'], "followup") !== false)
				{
					if($each_context['name'] == 'abc-verification-followup')
						array_push($context_out, array("name"=> $each_context['name'], "lifespan"=>0));
				}
			}
		}

		return $context_out;
	}


	public function company_search($parameters)
	{
		$api_response = array();

		$homepage = file_get_contents('https://api.opencorporates.com/v0.4/companies/search?q='.urlencode($parameters['comp-name']).'&jurisdiction_code=us_ca');

		/*$homepage = '{"api_version":"0.4","results":{"companies":[{"company":{"name":"SOLIX TECHNOLOGIES INCORPORATED","company_number":"C2473286","jurisdiction_code":"us_ca","incorporation_date":"2002-10-18","dissolution_date":null,"company_type":"Foreign Stock","registry_url":"https://businessfilings.sos.ca.gov/frmDetail.asp?CorpID=02473286","branch_status":"branch of an out-of-jurisdiction company","inactive":false,"current_status":"Active","created_at":"2011-09-21T22:26:01+00:00","updated_at":"2016-12-16T15:24:03+00:00","retrieved_at":"2016-11-27T10:14:48+00:00","opencorporates_url":"https://opencorporates.com/companies/us_ca/C2473286","previous_names":[],"source":{"publisher":"California Secretary of State","url":"https://businessfilings.sos.ca.gov/frmDetail.asp?CorpID=02473286","retrieved_at":"2016-11-27T10:14:48+00:00"},"registered_address":{"street_address":"4701 PATRICK HENRY DR.,,BLDG 20\nSANTA CLARA, CA 95054","locality":null,"region":null,"postal_code":null,"country":"United States"},"registered_address_in_full":"4701 PATRICK HENRY DR.,,BLDG 20\nSANTA CLARA, CA 95054","restricted_for_marketing":null,"native_company_number":null}},{"company":{"name":"SOLIX, INC.","company_number":"C2718911","jurisdiction_code":"us_ca","incorporation_date":"2005-01-21","dissolution_date":null,"company_type":"Foreign Stock","registry_url":"https://businessfilings.sos.ca.gov/frmDetail.asp?CorpID=02718911","branch_status":"branch of an out-of-jurisdiction company","inactive":false,"current_status":"Active","created_at":"2011-09-22T10:49:39+00:00","updated_at":"2016-12-19T16:39:51+00:00","retrieved_at":"2016-11-29T15:31:45+00:00","opencorporates_url":"https://opencorporates.com/companies/us_ca/C2718911","previous_names":[],"source":{"publisher":"California Secretary of State","url":"https://businessfilings.sos.ca.gov/frmDetail.asp?CorpID=02718911","retrieved_at":"2016-11-29T15:31:45+00:00"},"registered_address":{"street_address":"30 LANIDEX PLAZA WEST,\nPARSIPPANY, NJ 07054","locality":null,"region":null,"postal_code":null,"country":"United States"},"registered_address_in_full":"30 LANIDEX PLAZA WEST,\nPARSIPPANY, NJ 07054","restricted_for_marketing":null,"native_company_number":null}}],"page":1,"per_page":30,"total_pages":1,"total_count":2}}';*/

		$details = json_decode($homepage,true);


		if(!empty($details) && isset($details['results']) && isset($details['results']['companies']) && count($details['results']['companies'])>0)
		{

			if(count($details['results']['companies']) == 1)
			{

				//Update license verification action for this company in TCA DB



				if(strtolower($details['results']['companies'][0]['company']['current_status']) == 'active')
				{
					$company_details = "The Business License Number is ".$details['results']['companies'][0]['company']['current_status']." and its entity no is ".$details['results']['companies'][0]['company']['company_number'].".";
				}
				else
				{
					$company_details = "The Business License Number is ".$details['results']['companies'][0]['company']['current_status'].". ";	
				}

				/*$company_details .= "<b>".$details['results']['companies'][0]['company']['name']."</b> <br>";
				if(isset($details['results']['companies'][0]['company']['registered_address']) && !empty($details['results']['companies'][0]['company']['registered_address']))
				{
					$company_details .= $details['results']['companies'][0]['company']['registered_address']['street_address']."<br>".$details['results']['companies'][0]['company']['registered_address']['country']."<br>";
				}

				$company_details .= "license No:".$details['results']['companies'][0]['company']['company_number']."<br>";

				if(strtolower($details['results']['companies'][0]['company']['current_status']) == 'active')
					$color = 'color:green;';
				else
					$color = '';

				$company_details .= "Status: <b style=\"".$color."\">".$details['results']['companies'][0]['company']['current_status']."</b> <br>";*/

				$api_response['displayText'] = $company_details." ".$this->any_help_text;
				$api_response["clearContext"] = true;
			}
			else
			{

				$response_companies = '';
				if(count($geo_json->results) > 5)
				{
					$response_companies = "I see ".count($details['results']['companies'])." entities sharing similar name. Here are the Top 5. \n ";
				}
				else
				{
					$response_companies = "I see ".count($details['results']['companies'])." entities sharing similar name. Choose one from below. \n ";
				}

				foreach ($details['results']['companies'] as $k => $each_entity) {
					
					$response_companies .= $each_entity['company']['name'];
					if($k != (count($details['results']['companies']) - 1))
						$response_companies .= "<br >";

					if($k >= 4)
						break;
				}

				//$response_companies = 'I see number of entities sharing similar name. Just to be sure. Please give me the complete name of the company';

	            /*foreach ($details['results']['companies'] as $key => $company) {
	               $response_companies .= '<b>'.$company['company']['name'].'</b> <br><br>';
	            }*/

				$api_response['displayText'] = $response_companies;
			}

			$api_response['search_results'] = $details;
		}
		else
		{
			$response_companies = "I did not find any entity with this name. Please verify the name of the company.";
			$api_response['displayText'] = $response_companies;
		}

		return $api_response;
	}
	
	public function address_verification($parameters)
	{
		$api_response = array();
		$address_array = array();
		$address = $company_name = $parameters['comp-name'];
		if(isset($parameters['comp-address']) && !empty($parameters['comp-address']))
		{
			if(is_array($parameters['comp-address']) && count($parameters['comp-address'])>0)
			{
				foreach ($parameters['comp-address'] as $a_key => $a_value) {
					if(strtolower($a_key) == 'street-address'){
						$address_array['street-address'] = $a_value;
						$address .= ", ".$a_value;
					}
					else if(strtolower($a_key) == 'city')
					{
						$address_array['city'] = $a_value;
						$address .= ", ".$a_value;
					}
					else if(strtolower($a_key) == 'admin-area'){
						$address_array['state'] = $a_value;
						$address .= ", ".$a_value;
					}
					else if(strtolower($a_key) == 'subadmin-area'){
						$address_array['city'] = $a_value;
						$address .= ", ".$a_value;
					}
					else if(strtolower($a_key) == 'country'){
						$address_array['country'] = $a_value;
						$address .= ", ".$a_value;
					}
					else if(strtolower($a_key) == 'zip-code'){
						$address_array['zip-code'] = $a_value;
						$address .= ", ".$a_value;
					}
				}
			}
			else if(!is_array($parameters['comp-address']))
				$address .= ", ".$parameters['comp-address'];
		}

		$key = "AIzaSyBvju9zZ7qbdU4wKtONXpmZahZezfAZVDM";
		$url = "https://maps.googleapis.com/maps/api/place/textsearch/json?query=".urlencode($address)."&key=".$key;

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_HEADER,false);
		curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"]);
		// Comment out the line below if you receive an error on certain hosts that have security restrictions
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$data = curl_exec($ch);

		curl_close($ch);

		$geo_json = json_decode($data);

		if ($geo_json->status == 'OK')
		{
			//Address Verified TCA DB action



			if(count($geo_json->results)==1)
			{
				

				if(isset($parameters['comp-address']) && !empty($parameters['comp-address']))
				{

					if(is_array($parameters['comp-address']) && count($parameters['comp-address'])>0)
					{

					}


					$response_text = "The address is valid! \n The address of ".$geo_json->results[0]->name." is <br>".$geo_json->results[0]->formatted_address.$this->any_help_text;
					$api_response["displayText"] = $response_text;

				}
				else
				{
					$api_response["displayText"] = "The address of ".$geo_json->results[0]->name." is <br>".$geo_json->results[0]->formatted_address.$this->any_help_text;
				}

				$api_response["clearContext"] = true;
			}
			else
			{
				$response_text = '';
				if(count($geo_json->results) > 5)
				{
					$response_text = "I see ".count($geo_json->results)." entities sharing similar name. Here are the Top 5.\n ";
				}
				else
				{
					$response_text = "I see ".count($geo_json->results)." entities sharing similar name. Choose one from below.\n ";
				}

				foreach ($geo_json->results as $k => $each_entity) {
					
					$response_text .= $each_entity->name."<br>".$each_entity->formatted_address;
					if($k != (count($geo_json->results) - 1))
						$response_text .= "<br ><br >";

					if($k >= 4)
						break;
				}


				$api_response["displayText"] = $response_text;
			}

			/*$latitude  = $geo_json->results[0]->geometry->location->lat; 
	 		$longitude = $geo_json->results[0]->geometry->location->lng;

	 		$map_url = '<iframe width="240px" height="250px" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="
				http://maps.google.com/maps
				?f=q
				&source=s_q
				&hl=en
				&geocode=
				&q='.$address.'
				&aq=0
				&ie=UTF8
				&hq=
				&hnear='.$address.'
				&t=m
				&ll='.$longitude.','.$latitude.'
				&z=4
				&iwloc=
				&output=embed"></iframe>';

			$api_response["displayText"] = $map_url;*/
		}
		else
		{
			$api_response["displayText"] = "Couldn't find any address of the entity. Please check the company name again.";
		}

		return $api_response;
	}

	public function abc_verification($parameters)
	{
		$api_response = array();

		if(isset($parameters['licence-number']) && !empty($parameters['licence-number']))
		{
			$api_response = $this->abc_verification_licence($parameters);
		}
		else if(isset($parameters['comp-name']) && !empty($parameters['comp-name']))
		{
			$api_response = $this->abc_verification_name($parameters);
		}

		return $api_response;
	}

	function my_search($haystack)
	{
	    global $needle;
	    if( strpos($haystack, $needle) === false) {return false;} else {return true;}
	}

	public function abc_verification_licence($parameters, $license_text_result='')
	{
		$api_response = array();

		if(empty($license_text_result))
		{
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, 'https://www.abc.ca.gov/datport/LQSBrkDwn.asp?LQSCall=LIC');
			curl_setopt($ch, CURLOPT_POST, 1);
			//curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: text/xml'));
			curl_setopt($ch, CURLOPT_POSTFIELDS, 'q_License_Num='.substr($parameters['licence-number'],-6));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
			$result = curl_exec($ch);

			$data=$result;
		}
		else
			$data = $license_text_result;

		$values_to_get=array(0=>'License Number:', 1=>'Primary Owner:', 2=>'Doing Business As:', 3=>'Address:', 4=>'Census Tract:', 5=>'City:', 6=>'County:', 7=>'State:', 8=>'Zip Code:', 9=>'Licensee:', 10=>'License Type:', 11=>'License Type Status:', 12=>'Expiration Date:');

		$tables_data = array();

		$dom = new domDocument; 
		$dom->loadHTML($data); 
		$dom->preserveWhiteSpace = false; 


		if($dom->getElementsByTagName('table')->length > 1)
		{
			$secondTable = $dom->getElementsByTagName('table')->item(1);

			// iterate over each row in the table
			foreach($secondTable->getElementsByTagName('tr') as $tr)
			{
			    $tds = $tr->getElementsByTagName('td'); // get the columns in this row
			    if($tds->length >= 1)
			    {
			    	$stringtocheck = strtolower(trim($tds->item(0)->nodeValue));
					foreach ($values_to_get as $each_key => $each_value)
					{
						//echo $stringtocheck."=>".$name."\r\n";
				        if (stripos($stringtocheck, $each_value) !== FALSE)
				        {
				            $final_string = trim(str_replace($each_value, '',stristr(trim($tds->item(0)->nodeValue), $each_value)));
				            $final_string = htmlentities($final_string, null, 'utf-8');
				            $tables_data[$each_key] = str_replace('&nbsp;', '',$final_string);
				        }
				    }
			    }
			}

			foreach ($tables_data as $tKey => $tValue)
			{
				foreach ($values_to_get as $each_key => $each_value)
				{
			        if (stripos($tValue, $each_value) !== FALSE)
			            $tables_data[$tKey] = trim(str_replace('&nbsp;', '',(stristr(trim($tValue), $each_value, true))));
			    }
			}
		}
		
		if(count($tables_data))
		{
			if(isset($parameters['comp-name']) && !empty($parameters['comp-name']))
			{
				if(strpos(strtolower($tables_data[2]), strtolower($parameters['comp-name'])) !== false || strpos(strtolower($tables_data[1]), strtolower($parameters['comp-name'])) !== false){
					$response_text = "This place has an ".$tables_data[11]." Alcohol beverage license.";

					$api_response["clearContext"] = true;
				}
				else
					$response_text = "ABC Verification failed, The license number and company name does not match.".$this->any_help_text;
			}
			else
			{
				$response_text = "This place has an ".$tables_data[11]." Alcohol beverage license.";

				$api_response["clearContext"] = true;
			}

			if(isset($api_response["clearContext"]) && $api_response["clearContext"])
			{
				if(!empty($tables_data[12]))
				{
					if(strtotime('now') <= strtotime($tables_data[12]))
						$response_text .= " It's license is going to be expires on ".$tables_data[12].".";
				}

				$address_line = "";
				if(isset($tables_data[2]) && !empty($tables_data[2]))
					$address_line = $tables_data[2];
				else if(isset($tables_data[1]) && !empty($tables_data[1]))
					$address_line = $tables_data[1];

				if(isset($tables_data[3]) && !empty($tables_data[3]))
					$address_line .= ", ".$tables_data[3];

				if(isset($tables_data[5]) && !empty($tables_data[5]))
					$address_line .= ", ".$tables_data[5];

				if(isset($tables_data[6]) && !empty($tables_data[6]))
					$address_line .= ", ".$tables_data[6];

				if(isset($tables_data[7]) && !empty($tables_data[7]))
					$address_line .= ", ".$tables_data[7];

				if(isset($tables_data[8]) && !empty($tables_data[8]))
					$address_line .= ", ".$tables_data[8];

				if($address_line != '')
					$response_text .= "<br >".$address_line;

				$response_text .= $this->any_help_text;
			}


			$api_response['displayText'] = str_replace("&nbsp;", "", $response_text);
			
		}
		else
		{			
			if(isset($parameters['name-licence-number']) && !empty($parameters['name-licence-number']))
				$api_response['displayText'] = "I did not find any entity with this name. Please verify the name of the company.";
			else 
				$api_response['displayText'] = "ABC Verification failed, Check your license number.";
		}

		return $api_response;
	}

	public function abc_verification_name($parameters)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "http://abc.ca.gov/datport/LQSDBALst.asp?DBA='".urlencode(strtoupper($parameters['comp-name']))."'");
		curl_setopt($ch, CURLOPT_POST, 1);
		//curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: text/xml'));
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
		//curl_setopt($ch, CURLOPT_POSTFIELDS, 'OWNRCRIT="q_Company"');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		$result = curl_exec($ch);
		//echo $result;
		$dom = new domDocument; 
		$dom->loadHTML($result); 
		$dom->preserveWhiteSpace = false; 
		$finder = new DomXPath($dom);
		//$tables = $finder->query("//*[contains(@class, 'content')]");
		$tables = $finder->query('//table[contains(concat(" ", normalize-space(@class), " "), " content ")]');
		

		if($tables->length > 0)
		{
			$rows = $tables->item(0)->getElementsByTagName('tr'); 

			$companies_list = array();
			foreach ($rows as $row) {
				$cols = $row->getElementsByTagName('td'); 
				if(!empty($cols->item(1)->nodeValue) && $cols->item(1)->nodeValue != null)
				{
					array_push($companies_list ,array('res'=>1,'DBA_Name'=>$cols->item(1)->nodeValue, 'City'=>$cols->item(2)->nodeValue,'License_Number'=>$cols->item(3)->nodeValue, 'License_Type_Codes_and_Statuses'=>$cols->item(4)->nodeValue));
				}
			}

			if(!empty($companies_list))
			{
				if(count($companies_list) != 1)
				{
					if(count($companies_list) > 5)
					{
						$response_text = "I see ".count($companies_list)." entities sharing similar name. Here are the Top 5.\n ";
					}
					else if(count($companies_list) > 1)
					{
						$response_text = "I see ".count($companies_list)." entities sharing similar name. Choose one from below.\n ";
					}

					foreach ($companies_list as $k => $each_company) {
						
						$response_text .= "Entity name: ".$each_company['DBA_Name']."<br >";
						$response_text .= "City: ".$each_company['City']."<br >";
						$response_text .= "License number: ".$each_company['License_Number']."<br >";

						if($k != (count($this->customer_names) - 1))
							$response_text .= "<br >";

						if($k >= 4)
							break;
					}

					$response_text .= "Please enter the license number of the company to verify";

					$api_response['displayText'] = $response_text;
				}
				else if(count($companies_list) == 1)
				{
					$parameters['licence-number'] = $companies_list[0]['License_Number'];
					$parameters['name-licence-number'] = 1;
					$api_response = $this->abc_verification_licence($parameters);
				}
			}
			else
			{
				$response_companies = "I did not find any entity with this name. Please verify the name of the company.";
				$api_response['displayText'] = $response_companies;
			}

			/*else if(empty($companies_list) && !empty($result))
			{
				$api_response = $this->abc_verification_licence($parameters,$result);
			}*/
		}
		else
		{
			$response_companies = "I did not find any entity with this name. Please verify the name of the company.";
			$api_response['displayText'] = $response_companies;
		}


		return $api_response;
	}

	public function get_string_between($string, $start, $end){
	    $string = ' ' . $string;
	    $ini = strpos($string, $start);
	    if ($ini == 0) return '';
	    $ini += strlen($start);
	    $len = strpos($string, $end, $ini) - $ini;
	    return substr($string, $ini, $len);
	}

	

	public function ofac_sdn_verification($parameters)
	{
		$api_response = array();
		$sdn_results = array();
		$name = $parameters['sdn-name'];
		$xml = simplexml_load_file("https://www.treasury.gov/ofac/downloads/sdn.xml");

		$response_text = '';
		foreach ($xml->sdnEntry as $sdn)
		{
			
			if(strtolower($sdn->lastName) != strtolower($name))
			{
				$sdnSearch="$sdn->firstName";
			}
			else
			{
				$sdnSearch="$sdn->lastName";
				//var_dump(strtolower($name));
			}

			/*$sdnSearch = '';
			if(!empty($sdn->firstName))
				$sdnSearch .= $sdn->firstName;

			if(!empty($sdn->lastName))
			{
				if(!empty($sdn->firstName))
					$sdnSearch .= " ".$sdn->lastName;
				else
					$sdnSearch .= $sdn->lastName;
			}

			$sdnSearch = preg_replace('/[^A-Za-z0-9\-]/', '', $sdnSearch);*/

			//var_dump(strtolower($name));
			//$pos = strpos($mystring, $findme)
			//if(stripos(strtolower($sdnSearch), strtolower($name)) !== false){
			if(strtolower($sdnSearch) == strtolower($name)){
				
				if($sdn->sdnType=="Entity")
				{
					/* echo $sdn->sdnType."<br/>";
					echo $sdn->lastName."<br/>";
					//echo $sdn->title."<br/>";
					//echo $sdn->remarks."<br/>";
					echo $sdn->programList->program."<br/>";
					//echo $sdn->dateOfBirthList->dateOfBirthItem->dateOfBirth."<br/>";
					echo $sdn->addressList->address->address1."<br/>";
					echo $sdn->addressList->address->address2."<br/>";
					echo $sdn->addressList->address->city."<br/>";
					echo $sdn->addressList->address->postalCode."<br/>";
					echo $sdn->addressList->address->country."<br/>";
					 */
					array_push($sdn_results, array('res'=>1,'sdnType'=>$sdn->sdnType, 'lastName'=>$sdn->lastName,'program'=>$sdn->programList->program, 'address'=>$sdn->addressList->address->address1.' '.$sdn->addressList->address->address2.' '.$sdn->addressList->address->city.' '.$sdn->addressList->address->postalCode.' '.$sdn->addressList->address->country));

					$response_text = "SDN Type: ".$sdn->sdnType."<br>Entity Name: ".$sdn->lastName."<br>Program: ".$sdn->programList->program;

					if(isset($sdn->remarks) && !empty($sdn->remarks))
						$response_text .= "<br>Remarks: ".$sdn->remarks;

					$response_address = '';

					if(!empty($sdn->addressList->address->address1) || !empty($sdn->addressList->address->address2) || !empty($sdn->addressList->address->city) || !empty($sdn->addressList->address->country) || !empty($sdn->addressList->address->postalCode))
						$response_address .= "<br>Address:";

					if(!empty($sdn->addressList->address->address1))
						$response_address .= " ".$sdn->addressList->address->address1;

					if(!empty($sdn->addressList->address->address2))
						$response_address .= " ".$sdn->addressList->address->address2;

					if(!empty($sdn->addressList->address->city))
						$response_address .= " ".$sdn->addressList->address->city;

					if(!empty($sdn->addressList->address->postalCode))
						$response_address .= " ".$sdn->addressList->address->postalCode;

					if(!empty($sdn->addressList->address->country))
						$response_address .= " ".$sdn->addressList->address->country;		

					if(!empty($response_address))
						$response_text .= $response_address;
				}
				else if($sdn->sdnType=="Individual")
				{
					/* echo $sdn->sdnType."<br/>";
					echo $sdn->firstName."<br/>";
					echo $sdn->lastName."<br/>";
					//echo $sdn->remarks."<br/>";
					echo $sdn->programList->program."<br/>";
					echo $sdn->dateOfBirthList->dateOfBirthItem->dateOfBirth."<br/>";
					echo $sdn->placeOfBirthList->placeOfBirthItem->placeOfBirth."<br/>";
					echo $sdn->nationalityList->nationality->country."<br/>"; */
					array_push($sdn_results,array('res'=>1,'sdnType'=>$sdn->sdnType, 'lastName'=>$sdn->lastName,'firstName'=>$sdn->firstName, 'program'=>$sdn->programList->program,'remarks'=>$sdn->remarks,'dateOfBirth'=>$sdn->dateOfBirthList->dateOfBirthItem->dateOfBirth, 'placeOfBirth'=>$sdn->placeOfBirthList->placeOfBirthItem->placeOfBirth,'nationality'=>$sdn->nationalityList->nationality->country));

					$sdn_person_name = '';
					if(!empty($sdn->firstName))
						$sdn_person_name .= $sdn->firstName;

					if(!empty($sdn->lastName))
					{
						if(!empty($sdn->firstName))
							$sdn_person_name .= " ".$sdn->lastName;
						else
							$sdn_person_name .= $sdn->lastName;
					}


					$response_text = "SDN Type: ".$sdn->sdnType."<br>Individual Name: ".$sdn_person_name."<br>Program: ".$sdn->programList->program;

					if(isset($sdn->remarks) && !empty($sdn->remarks))
						$response_text .= "<br>Remarks: ".$sdn->remarks;

					if(isset($sdn->dateOfBirthList->dateOfBirthItem->dateOfBirth) && !empty($sdn->dateOfBirthList->dateOfBirthItem->dateOfBirth))
						$response_text .="<br>Date of birth: ".$sdn->dateOfBirthList->dateOfBirthItem->dateOfBirth;

					if(isset($sdn->placeOfBirthList->placeOfBirthItem->placeOfBirth) && !empty($sdn->placeOfBirthList->placeOfBirthItem->placeOfBirth))
						$response_text .="<br>Place of birth: ".$sdn->placeOfBirthList->placeOfBirthItem->placeOfBirth;

					if(isset($sdn->nationalityList->nationality->country) && !empty($sdn->nationalityList->nationality->country))
						$response_text .="<br>Nationality: ".$sdn->nationalityList->nationality->country;
				}
				else if($sdn->sdnType=="Vessel")
				{
					/* echo $sdn->sdnType."<br/>";
					echo $sdn->lastName."<br/>";
					echo $sdn->remarks."<br/>";
					echo $sdn->programList->program."<br/>";
					echo $sdn->vesselInfo->vesselType."<br/>";
					echo $sdn->vesselInfo->vesselFlag."<br/>"; */
					array_push($sdn_results,array('res'=>1,'sdnType'=>$sdn->sdnType, 'VessalName'=>$sdn->lastName,'remarks'=>$sdn->remarks, 'program'=>$sdn->programList->program,'vesselType'=>$sdn->vesselInfo->vesselType, 'vesselFlag'=>$sdn->vesselInfo->vesselFlag));

					$response_text = "SDN Type: ".$sdn->sdnType."<br>Vessel Name: ".$sdn->lastName."<br>Program: ".$sdn->programList->program;
					
					if(isset($sdn->remarks) && !empty($sdn->remarks))
						$response_text .= "<br>Remarks: ".$sdn->remarks;

					if(isset($sdn->vesselInfo->vesselType) && !empty($sdn->vesselInfo->vesselType))
						$response_text .= "<br>Vessel Type: ".$sdn->vesselInfo->vesselType;

					if(isset($sdn->vesselInfo->vesselFlag) && !empty($sdn->vesselInfo->vesselFlag))
						$response_text .= "<br>Vessel Flag: ".$sdn->vesselInfo->vesselFlag;
				}
				else if($sdn->sdnType=="Aircraft")
				{
					/* echo $sdn->sdnType."<br/>";
					echo $sdn->lastName."<br/>";
					echo $sdn->remarks."<br/>";
					echo $sdn->programList->program."<br/>"; */
					array_push($sdn_results,array('res'=>1,'sdnType'=>$sdn->sdnType, 'AircraftName'=>$sdn->lastName,'program'=>$sdn->programList->program, 'remarks'=>$sdn->remarks));

					$response_text = "SDN Type: ".$sdn->sdnType."<br>Aircraft Name: ".$sdn->lastName."<br>Program: ".$sdn->programList->program;

					if(isset($sdn->remarks) && !empty($sdn->remarks))
						$response_text .= "<br>Remarks: ".$sdn->remarks;
				}

				$api_response["clearContext"] = true;
			}
		}

		if(empty($response_text))
			$response_text = "I could not find this name in OFAC SDN list.";

		$api_response['displayText'] = $response_text.$this->any_help_text;
		$api_response['data'] = $sdn_results;

		return $api_response;
	}


	public function connect_db()
	{
		$this->conn = mysql_connect('localhost','gia','gia321');

		mysql_select_db("gia_bariven");
	}


	//Customer Total Balance
	public function get_customer_id_from_name($customer_name)
	{
		if(!empty($customer_name))
		{
			$this->connect_db();
			$cus_name_qry = "SELECT CASH_CUS_ID AS SUM_CUSTOMER, CASH_CUS_NAME AS SUM_CUSTOMER_NAME FROM CASH_CUSTOMER WHERE CASH_CUS_NAME LIKE '".$customer_name."%'";
			$name_res = mysql_query($cus_name_qry, $this->conn) or die(mysql_error());

			if(is_resource($name_res))
			{
			   if($name_res !== false)
			   {
			   		if(mysql_num_rows($name_res) == 1)
			   		{
					  	$row = mysql_fetch_assoc($name_res);
						$this->customer_id = $row['SUM_CUSTOMER'];
						$this->db_customer_name = str_replace("\n", "", str_replace("\r", "", $row['SUM_CUSTOMER_NAME']));
					}
					else if(mysql_num_rows($name_res) > 1)
					{
						while($row = @mysql_fetch_assoc($name_res,MYSQL_ASSOC))
				        {
				           $this->customer_names[] = $row;
				        }
					}


			   }			  
			}			
		}
	}

	public function multiple_customers()
	{
		if(count($this->customer_names) > 5)
			$response_text = "I see ".count($this->customer_names)." customers with the same name. Here are the top 5.<br>";
		else
			$response_text = "I see ".count($this->customer_names)." customers with the same name. Choose one from below.<br>";

		foreach ($this->customer_names as $k => $each_customer) {
			
			$response_text .= $each_customer['SUM_CUSTOMER_NAME'];
			if($k != (count($this->customer_names) - 1))
				$response_text .= "<br >";

			if($k >= 4)
				break;
		}

		return $response_text;
	}

	public function get_total_balance($parameters)
	{
		$api_response = array();
		$customer_name = mysql_escape_string($parameters['customer-name']);
		$this->get_customer_id_from_name($customer_name);

		if(!empty($this->customer_id))
		{
			$total_balance =0;
			$total_bal_query = "SELECT SUM(IFNULL(CASH_TRAH_OVER_DUE_AMOUNT,0)+IFNULL(CASH_TRAH_CURR_DUE_AMOUNT,0)) AS SUM_TOTAL_BALANCE, SUM(CASH_TRAH_CURR_DUE_AMOUNT) AS SUM_CURRENT_BALANCE from CASH_TRANSACTION_HEADERS where CASH_TRAH_BILL_TO_CUSTOMER_ID='".mysql_escape_string($this->customer_id)."' AND CASH_TRAH_COMPLETE_FLAG !='Y' GROUP BY CASH_TRAH_BILL_TO_CUSTOMER_ID";
			$bal_res = mysql_query($total_bal_query,$this->conn);
			if(is_resource($bal_res))
			{
			   if($bal_res !== false)
			   {
			   		if(mysql_num_rows($bal_res) == 1)
			   		{
					  	$row = mysql_fetch_assoc($bal_res);

					  	$response_text = 'The total balance of the customer '.$this->db_customer_name.' is $'.number_format($row['SUM_TOTAL_BALANCE'],2).'.';

					  	if($row['SUM_CURRENT_BALANCE']>0)
					  		$response_text .= " The current balance is $".number_format($row['SUM_CURRENT_BALANCE'],2);

						//$response_text = 'This is the current balance $'.$row['SUM_CURRENT_BALANCE'].'  & the total balance $'.$row['SUM_TOTAL_BALANCE'].'  of the customer '.$row['SUM_CUSTOMER_NAME'];

						$api_response['data']['Image'] = '<img src="http://accelforce.com/gia/UI/new/graph.png">';
						$api_response["clearContext"] = true;
					}
			   }			  
			}
		}
		else if(count($this->customer_names)>1)
		{
			$response_text = $this->multiple_customers();
		}
		else
		{
			$response_text = $this->no_customer_text;
		}

		$api_response["displayText"] = $response_text;
		//print_r($api_response);

		return $api_response;
	}


	//Last paid amount and Last paid date
	public function get_last_paid_details($parameters)
	{

		$api_response = array();
		$customer_name = mysql_escape_string($parameters['customer-name']);
		$this->get_customer_id_from_name($customer_name);

		if(!empty($this->customer_id))
		{
			$total_balance =0;
			$total_bal_query = "SELECT CASH_TRAH_LAST_PAID_AMOUNT AS SUM_LAST_PAID_AMOUNT, CASH_TRAH_LAST_PAID_DATE AS SUM_LAST_PAID_DATE from CASH_TRANSACTION_HEADERS where CASH_TRAH_BILL_TO_CUSTOMER_ID='".mysql_escape_string($this->customer_id)."' AND CASH_TRAH_LAST_PAID_AMOUNT>0 ORDER BY SUM_LAST_PAID_DATE DESC LIMIT 1";
			$bal_res = mysql_query($total_bal_query,$this->conn);
			if(is_resource($bal_res))
			{
			   if($bal_res !== false)
			   {
			   		if(mysql_num_rows($bal_res) == 1)
			   		{
					  	$row = mysql_fetch_assoc($bal_res);

					  	if($row['SUM_LAST_PAID_AMOUNT'] >0)
					  	{
					  		$response_text = 'The last paid amount by '.$this->db_customer_name.' is $'.number_format($row['SUM_LAST_PAID_AMOUNT'],2).' on '.date("d F Y", strtotime($row['SUM_LAST_PAID_DATE'])).'.';
					  	}
					  	else 
					  	{
					  		$total_bal_query = "SELECT SUM(IFNULL(CASH_TRAH_OVER_DUE_AMOUNT,0)+IFNULL(CASH_TRAH_CURR_DUE_AMOUNT,0)) AS SUM_TOTAL_BALANCE, SUM(CASH_TRAH_CURR_DUE_AMOUNT) AS SUM_CURRENT_BALANCE from CASH_TRANSACTION_HEADERS where CASH_TRAH_BILL_TO_CUSTOMER_ID='".mysql_escape_string($this->customer_id)."' AND CASH_TRAH_COMPLETE_FLAG !='Y' GROUP BY CASH_TRAH_BILL_TO_CUSTOMER_ID";
							$bal_res = mysql_query($total_bal_query,$this->conn);
							$total_bal_row = mysql_fetch_assoc($bal_res);

					  		$response_text = 'You did not receive any payment from '.$this->db_customer_name.' till now. Your total balance is $'.number_format($total_bal_row['SUM_TOTAL_BALANCE'],2).'.';
					  	}

					  	$api_response["clearContext"] = true;						
					}
					else
					{
						$total_bal_query = "SELECT SUM(IFNULL(CASH_TRAH_OVER_DUE_AMOUNT,0)+IFNULL(CASH_TRAH_CURR_DUE_AMOUNT,0)) AS SUM_TOTAL_BALANCE, SUM(CASH_TRAH_CURR_DUE_AMOUNT) AS SUM_CURRENT_BALANCE from CASH_TRANSACTION_HEADERS where CASH_TRAH_BILL_TO_CUSTOMER_ID='".mysql_escape_string($this->customer_id)."' AND CASH_TRAH_COMPLETE_FLAG !='Y' GROUP BY CASH_TRAH_BILL_TO_CUSTOMER_ID";
							$bal_res = mysql_query($total_bal_query,$this->conn);
							$total_bal_row = mysql_fetch_assoc($bal_res);

					  		$response_text = 'You did not receive any payment from '.$this->db_customer_name.' till now. Your total balance is $'.number_format($total_bal_row['SUM_TOTAL_BALANCE'],2).'.';
					}
			   }			  
			}
		}
		else if(count($this->customer_names)>1)
		{
			$response_text = $this->multiple_customers();
		}
		else
			$response_text = $this->no_customer_text;

		$api_response["displayText"] = $response_text;

		return $api_response;
	}


	//Current/Open Invoices
	public function get_current_invoices_details($parameters)
	{

		$api_response = array();
		$customer_name = mysql_escape_string($parameters['customer-name']);
		$this->get_customer_id_from_name($customer_name);

		if(!empty($this->customer_id))
		{
			$total_balance =0;
			$curr_inv_qry = "SELECT COUNT(*) AS CUR_INVOICE_CNT, SUM(CASH_TRAH_CURR_DUE_AMOUNT) AS SUM_CURRENT_BALANCE, SUM(IFNULL(CASH_TRAH_OVER_DUE_AMOUNT,0)+IFNULL(CASH_TRAH_CURR_DUE_AMOUNT,0)) AS SUM_TOTAL_BALANCE FROM CASH_TRANSACTION_HEADERS WHERE CASH_TRAH_BILL_TO_CUSTOMER_ID='".mysql_escape_string($this->customer_id)."' AND CASH_TRAH_COMPLETE_FLAG !='Y'";

			//$total_bal_query = "SELECT SUM_LAST_PAID_AMOUNT,SUM_LAST_PAID_DATE,SUM_CUSTOMER_NAME,SUM_TOTAL_BALANCE, SUM_CURRENT_BALANCE from `summary` where SUM_CUSTOMER='".mysql_escape_string($this->customer_id)."'";
			$cur_inv_res = mysql_query($curr_inv_qry,$this->conn);
			if(is_resource($cur_inv_res))
			{
			   if($cur_inv_res !== false)
			   {
			   		if(mysql_num_rows($cur_inv_res) == 1)
			   		{
					  	$row = mysql_fetch_assoc($cur_inv_res);

					  	if($row['CUR_INVOICE_CNT'] >0)
					  	{
					  		$response_text = 'There are '.$row['CUR_INVOICE_CNT'].' open invoices for '.$this->db_customer_name.'.';
					  		if($row['SUM_CURRENT_BALANCE']>0)
					  			$response_text .=' The total current balance is $'.number_format($row['SUM_CURRENT_BALANCE'],2).'.';

					  		if($row['SUM_TOTAL_BALANCE']>0)
					  			$response_text .=' The total balance is $'.number_format($row['SUM_TOTAL_BALANCE'],2).'.';

					  		$curr_inv_list_qry = "SELECT * FROM CASH_TRANSACTION_HEADERS WHERE CASH_TRAH_BILL_TO_CUSTOMER_ID='".mysql_escape_string($this->customer_id)."' AND CASH_TRAH_COMPLETE_FLAG!='Y' ORDER BY CASH_TRAH_TRX_DATE DESC LIMIT 5";

					  		$curr_inv_list_res = mysql_query($curr_inv_list_qry);

					  		$current_invoices_text = "";
					  		$current_invoices_list = array();
					  		if(is_resource($curr_inv_list_res) && $curr_inv_list_res !== false)
					  		{
					  			if($row['CUR_INVOICE_CNT'] > 5)
					  				$current_invoices_text = "<br>Below are the last 5 invoice details<br>";
					  			else	
					  				$current_invoices_text = "<br>Below are the invoice details<br>";

					  			while($cr_row = @mysql_fetch_assoc($curr_inv_list_res,MYSQL_ASSOC))
						        {
						           array_push($current_invoices_list, $cr_row);

						           $current_invoices_text .= "INV#".$cr_row['CASH_TRAH_NUMBER']." | $".number_format($cr_row['CASH_TRAH_DUE_AMOUNT'],2)." invoice amount | ".date("m/d/Y",strtotime($cr_row['CASH_TRAH_TRX_DUE_DATE']))." due date <br>";
						        }
					  		}

					  		$response_text .= $current_invoices_text;

					  	}
					  	else
					  		$response_text = 'There are no current invoices for '.$this->db_customer_name.'.';

					  	$api_response["clearContext"] = true;

						//$response_text = 'This is the current balance $'.$row['SUM_CURRENT_BALANCE'].'  & the total balance $'.$row['SUM_TOTAL_BALANCE'].'  of the customer '.$row['SUM_CUSTOMER_NAME'];
					}
			   }			  
			}
		}
		else if(count($this->customer_names)>1)
		{
			$response_text = $this->multiple_customers();
		}
		else
			$response_text = $this->no_customer_text;

		$api_response["displayText"] = $response_text;

		return $api_response;
	}
	


	//Past Invoices
	public function get_past_invoices_details($parameters)
	{

		$api_response = array();
		$customer_name = mysql_escape_string($parameters['customer-name']);
		$this->get_customer_id_from_name($customer_name);

		if(!empty($this->customer_id))
		{
			$total_balance =0;
			$prev_inv_qry = "SELECT count(distinct SUM_CUSTOMER_NAME), COUNT(*) AS PRE_INVOICE_CNT FROM summary WHERE SUM_CUSTOMER='".mysql_escape_string($this->customer_id)."' AND SUM_PREV_BALANCE>0 AND SUM_CREDIT_RISK IS NOT NULL";

			//$total_bal_query = "SELECT SUM_LAST_PAID_AMOUNT,SUM_LAST_PAID_DATE,SUM_CUSTOMER_NAME,SUM_TOTAL_BALANCE, SUM_CURRENT_BALANCE from `summary` where SUM_CUSTOMER='".mysql_escape_string($this->customer_id)."'";
			$prev_inv_res = mysql_query($prev_inv_qry,$this->conn);
			if(is_resource($prev_inv_res))
			{
			   if($prev_inv_res !== false)
			   {
			   		if(mysql_num_rows($prev_inv_res) == 1)
			   		{
					  	$row = mysql_fetch_assoc($prev_inv_res);

					  	if($row['CUR_INVOICE_CNT'] >0)
					  		$response_text = 'The total past invoices for '.$this->db_customer_name.' are '.$row['PRE_INVOICE_CNT'].'.';
					  	else
					  		$response_text = 'There are no past invoices for '.$this->db_customer_name.'.';

					  	$api_response["clearContext"] = true;

						//$response_text = 'This is the current balance $'.$row['SUM_CURRENT_BALANCE'].'  & the total balance $'.$row['SUM_TOTAL_BALANCE'].'  of the customer '.$row['SUM_CUSTOMER_NAME'];
					}
			   }			  
			}
		}
		else if(count($this->customer_names)>1)
		{
			if(count($this->customer_names) > 5)
				$response_text = "I see ".count($this->customer_names)." customers with the same name. Here are the top 5 customers.<br>";
			else
				$response_text = "I see ".count($this->customer_names)." customers with the same name. Choose one from below.<br>";

			foreach ($this->customer_names as $k => $each_customer) {
				
				$response_text .= $each_customer['SUM_CUSTOMER_NAME'];
				if($k != (count($this->customer_names) - 1))
					$response_text .= "<br >";

				if($k >= 4)
					break;
			}
		}
		else
			$response_text = "I am not able to find any customer with that name. Please check again and give me the exact business name of the customer.";

		$api_response["displayText"] = $response_text;

		return $api_response;
	}


	//Dispute Invoices
	public function get_dispute_invoices_details($parameters)
	{

		$api_response = array();
		$customer_name = mysql_escape_string($parameters['customer-name']);
		$this->get_customer_id_from_name($customer_name);

		if(!empty($this->customer_id))
		{
			$total_balance =0;
			$curr_inv_qry = "SELECT COUNT(*) AS CUR_INVOICE_CNT, SUM(CASH_TRAH_DISPUTE_AMOUNT) AS SUM_DISPUTE_AMOUNT FROM CASH_TRANSACTION_HEADERS WHERE CASH_TRAH_BILL_TO_CUSTOMER_ID='".mysql_escape_string($this->customer_id)."' AND CASH_TRAH_COMPLETE_FLAG !='Y' AND CASH_TRAH_DISPUTE_AMOUNT>0";

			//$total_bal_query = "SELECT SUM_LAST_PAID_AMOUNT,SUM_LAST_PAID_DATE,SUM_CUSTOMER_NAME,SUM_TOTAL_BALANCE, SUM_CURRENT_BALANCE from `summary` where SUM_CUSTOMER='".mysql_escape_string($this->customer_id)."'";
			$cur_inv_res = mysql_query($curr_inv_qry,$this->conn);
			if(is_resource($cur_inv_res))
			{
			   if($cur_inv_res !== false)
			   {
			   		if(mysql_num_rows($cur_inv_res) == 1)
			   		{
					  	$row = mysql_fetch_assoc($cur_inv_res);

					  	if($row['CUR_INVOICE_CNT'] >0)
					  	{
					  		$total_bal_qry = "SELECT SUM(IFNULL(CASH_TRAH_OVER_DUE_AMOUNT,0)+IFNULL(CASH_TRAH_CURR_DUE_AMOUNT,0)) AS SUM_TOTAL_BALANCE FROM CASH_TRANSACTION_HEADERS WHERE CASH_TRAH_BILL_TO_CUSTOMER_ID='".mysql_escape_string($this->customer_id)."' AND CASH_TRAH_COMPLETE_FLAG !='Y'";
					  		$total_bal_res = mysql_query($total_bal_qry,$this->conn);
					  		$total_bal_row = @mysql_fetch_assoc($total_bal_res,MYSQL_ASSOC);


					  		$response_text = 'There are '.$row['CUR_INVOICE_CNT'].' disputed invoices for '.$this->db_customer_name.'.';
					  		
					  		if($total_bal_row['SUM_TOTAL_BALANCE']>0)
					  			$response_text .=' The total balance is $'.number_format($total_bal_row['SUM_TOTAL_BALANCE'],2).'.';

					  		if($row['SUM_DISPUTE_AMOUNT']>0)
					  			$response_text .=' The total dispute amount is $'.number_format($row['SUM_DISPUTE_AMOUNT'],2).'.';

					  		$curr_inv_list_qry = "SELECT * FROM DISPUTE_LIST_VIEW WHERE CUSTOMER='".mysql_escape_string($this->customer_id)."' AND DISPUTE_STATUS IN ('InProcess','Save', 'Adhoced', 'Clarify') AND DISPUTED_AMOUNT>0 ORDER BY DISPUTE_CREATION_DATE DESC LIMIT 5";

					  		$curr_inv_list_res = mysql_query($curr_inv_list_qry);

					  		$current_invoices_text = "";
					  		$current_invoices_list = array();
					  		if(is_resource($curr_inv_list_res) && $curr_inv_list_res !== false)
					  		{
					  			if($row['CUR_INVOICE_CNT'] > 5)
					  				$current_invoices_text = "<br>Below are the last 5 invoice details<br>";
					  			else	
					  				$current_invoices_text = "<br>Below are the invoice details<br>";

					  			while($cr_row = @mysql_fetch_assoc($curr_inv_list_res,MYSQL_ASSOC))
						        {
						           array_push($current_invoices_list, $cr_row);

						           $current_invoices_text .= "INV#".$cr_row['TRANSACTION_NUMBER']." | $".number_format($cr_row['DISPUTED_AMOUNT'],2)." dispute amount | ".date("m/d/Y",strtotime($cr_row['DISPUTE_CREATION_DATE']))." creation date <br>";
						        }
					  		}

					  		$response_text .= $current_invoices_text;

					  	}
					  	else
					  		$response_text = 'There are no disputed invoices for '.$this->db_customer_name.'.';

					  	$api_response["clearContext"] = true;

						//$response_text = 'This is the current balance $'.$row['SUM_CURRENT_BALANCE'].'  & the total balance $'.$row['SUM_TOTAL_BALANCE'].'  of the customer '.$row['SUM_CUSTOMER_NAME'];
					}
			   }			  
			}
		}
		else if(count($this->customer_names)>1)
		{
			$response_text = $this->multiple_customers();
		}
		else
			$response_text = $this->no_customer_text;

		$api_response["displayText"] = $response_text;

		return $api_response;
	}


//CASH_FOR_TRANSACT_NUMBER
//CASH_FOR_FORCAST_AMOUNT
//CASH_FOR_EXPECTED_DATE         
//CASH_FOR_FOLLOWUP_DATE         
//CASH_FOR_COLLECTION_STATUS     


	//PTP Invoices
	public function get_ptp_invoices_details($parameters)
	{

		$api_response = array();
		$customer_name = mysql_escape_string($parameters['customer-name']);
		$this->get_customer_id_from_name($customer_name);

		if(!empty($this->customer_id))
		{
			$total_balance =0;
			$curr_inv_qry = "SELECT COUNT(*) AS PTP_INVOICE_CNT, SUM(CASH_FOR_FORCAST_AMOUNT) AS SUM_PTP_AMOUNT FROM CASH_FORECASTS WHERE CASH_FOR_CUSTOMER_ID='".mysql_escape_string($this->customer_id)."' AND CASH_FOR_FORCAST_AMOUNT>0";

			//$total_bal_query = "SELECT SUM_LAST_PAID_AMOUNT,SUM_LAST_PAID_DATE,SUM_CUSTOMER_NAME,SUM_TOTAL_BALANCE, SUM_CURRENT_BALANCE from `summary` where SUM_CUSTOMER='".mysql_escape_string($this->customer_id)."'";
			$cur_inv_res = mysql_query($curr_inv_qry,$this->conn);
			if(is_resource($cur_inv_res))
			{
			   if($cur_inv_res !== false)
			   {
			   		if(mysql_num_rows($cur_inv_res) == 1)
			   		{
					  	$row = mysql_fetch_assoc($cur_inv_res);

					  	if($row['PTP_INVOICE_CNT'] >0)
					  	{
					  		$total_bal_qry = "SELECT SUM(IFNULL(CASH_TRAH_OVER_DUE_AMOUNT,0)+IFNULL(CASH_TRAH_CURR_DUE_AMOUNT,0)) AS SUM_TOTAL_BALANCE FROM CASH_TRANSACTION_HEADERS WHERE CASH_TRAH_BILL_TO_CUSTOMER_ID='".mysql_escape_string($this->customer_id)."' AND CASH_TRAH_COMPLETE_FLAG !='Y'";
					  		$total_bal_res = mysql_query($total_bal_qry,$this->conn);
					  		$total_bal_row = @mysql_fetch_assoc($total_bal_res,MYSQL_ASSOC);

					  		//$ptp_inv_qry = "SELECT SUM(CASH_FOR_FORCAST_AMOUNT) AS SUM_PTP_AMOUNT FROM CASH_FORECASTS WHERE CASH_FOR_CUSTOMER_ID='".mysql_escape_string($this->customer_id)."'";

					  		//$ptp_inv_res = mysql_query($ptp_inv_qry,$this->conn);
					  		//$ptp_bal_row = @mysql_fetch_assoc($ptp_inv_res,MYSQL_ASSOC);


					  		$response_text = 'There are '.$row['PTP_INVOICE_CNT'].' PTP invoices for '.$this->db_customer_name.'.';
					  		
					  		if($total_bal_row['SUM_TOTAL_BALANCE']>0)
					  			$response_text .=' The total balance is $'.number_format($total_bal_row['SUM_TOTAL_BALANCE'],2).'.';

					  		if($row['SUM_PTP_AMOUNT']>0)
					  			$response_text .=' The total PTP amount is $'.number_format($row['SUM_PTP_AMOUNT'],2).'.';

					  		$curr_inv_list_qry = "SELECT * FROM CASH_FORECASTS WHERE CASH_FOR_CUSTOMER_ID='".mysql_escape_string($this->customer_id)."' AND CASH_FOR_FORCAST_AMOUNT>0 ORDER BY CASH_FOR_EXPECTED_DATE DESC LIMIT 5";

					  		$curr_inv_list_res = mysql_query($curr_inv_list_qry,$this->conn);

					  		$current_invoices_text = "";
					  		$current_invoices_list = array();
					  		if(is_resource($curr_inv_list_res) && $curr_inv_list_res !== false)
					  		{
					  			if($row['PTP_INVOICE_CNT'] > 5)
					  				$current_invoices_text = "<br>Below are the last 5 invoice details<br>";
					  			else	
					  				$current_invoices_text = "<br>Below are the invoice details<br>";
					  			while($cr_row = @mysql_fetch_assoc($curr_inv_list_res,MYSQL_ASSOC))
						        {
						           array_push($current_invoices_list, $cr_row);

						           $current_invoices_text .= "PTP#".$cr_row['CASH_FOR_TRANSACT_NUMBER']." | $".number_format($cr_row['CASH_FOR_FORCAST_AMOUNT'],2)." PTP amount | ".date("m/d/Y",strtotime($cr_row['CASH_FOR_EXPECTED_DATE']))." expected date | ".$cr_row['CASH_FOR_COLLECTION_STATUS']." <br>";
						        }
					  		}

					  		$response_text .= $current_invoices_text;

					  	}
					  	else
					  		$response_text = 'There are no PTP invoices for '.$this->db_customer_name.'.';

					  	$api_response["clearContext"] = true;

						//$response_text = 'This is the current balance $'.$row['SUM_CURRENT_BALANCE'].'  & the total balance $'.$row['SUM_TOTAL_BALANCE'].'  of the customer '.$row['SUM_CUSTOMER_NAME'];
					}
			   }			  
			}
		}
		else if(count($this->customer_names)>1)
		{
			$response_text = $this->multiple_customers();
		}
		else
			$response_text = $this->no_customer_text;

		$api_response["displayText"] = $response_text;

		return $api_response;
	}
	

}
?>