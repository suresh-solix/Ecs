<?php
header("Access-Control-Allow-Origin: *");
header('Content-type: application/json');
$json = file_get_contents('php://input'); 
$request = json_decode($json, true);
$action = $request['result']['action'];
$sent_text = $request['result']['resolvedQuery'];
$parameters = $request["result"]["parameters"];
$contexts = $request["result"]["contexts"];

//file_put_contents("apirequest.json", $json);

$settings = file_get_contents("settings.json");
$json_settings = json_decode($settings, true);


include_once "gia-bot-api.php";
$gia_bot_api_obj = new GiaBotAPI();
$gia_bot_api_obj->accessToken = $json_settings['akey'];

$gia_bot_api_obj->assign_default_values();

$response_json = $context_out = array();

$is_clear_context = false;

if($action == 'weather') 
{
	//some logic
	$response_json = array(
					"speech" => "The weather is cool today",
					"displayText" => "The weather is cool today" );

}
else if($action == 'raining') 
{
	//some logic
	$response_json = array(
					"speech" => "There is 40% chance of rain",
					"displayText" => "There is 40% chance of rain" );
}
else if($action == 'licence-validation')
{
	$api_response = $gia_bot_api_obj->company_search($parameters);

	if(!empty($api_response))
	{
		$response_json = array(
					"speech" => $api_response['displayText'],
					"displayText" => $api_response['displayText']);

		$response_json['details'] = $api_response['search_results'];

		if(isset($api_response['clearContext']) && $api_response['clearContext'] === true)
			$is_clear_context = true;
	}

	$context_out = $gia_bot_api_obj->API_AI_Context_mapping($contexts,'licence', $is_clear_context);
}
else if($action == 'address-verification')
{
	$api_response = $gia_bot_api_obj->address_verification($parameters);

	if(!empty($api_response)){

		$response_json = array(
					"speech" => $api_response['displayText'],
					"displayText" => $api_response['displayText']);

		if(isset($api_response['clearContext']) && $api_response['clearContext'] === true)
			$is_clear_context = true;
	}

	$context_out = $gia_bot_api_obj->API_AI_Context_mapping($contexts,'address', $is_clear_context);
}
else if($action == 'abc-verification')
{
	$api_response = $gia_bot_api_obj->abc_verification($parameters);
	if(!empty($api_response)){

		$response_json = array(
					"speech" => $api_response['displayText'],
					"displayText" => $api_response['displayText']);

		if(isset($api_response['clearContext']) && $api_response['clearContext'] === true)
			$is_clear_context = true;
	}

	$context_out = $gia_bot_api_obj->API_AI_Context_mapping($contexts,'abc', $is_clear_context);
}
else if($action == 'sdn-verification')
{
	$api_response = $gia_bot_api_obj->ofac_sdn_verification($parameters);
	if(!empty($api_response)){

		$response_json = array(
					"speech" => $api_response['displayText'],
					"displayText" => $api_response['displayText']);

		if(isset($api_response['clearContext']) && $api_response['clearContext'] === true)
			$is_clear_context = true;
	}

	$context_out = $gia_bot_api_obj->API_AI_Context_mapping($contexts,'ofac', $is_clear_context);
}
else if($action == 'total-balance' || $action == 'total-balance.total-balance-custom')
{
	$api_response = $gia_bot_api_obj->get_total_balance($parameters);
	if(!empty($api_response)){

		$response_json = array(
					"speech" => $api_response['displayText'],
					"displayText" => $api_response['displayText']);

		if(isset($api_response['clearContext']) && $api_response['clearContext'] === true)
			$is_clear_context = true;
	}

	$context_out = $gia_bot_api_obj->API_AI_Context_mapping($contexts,'balance', $is_clear_context);
}
else if($action == 'last-payment-details')
{
	$api_response = $gia_bot_api_obj->get_last_paid_details($parameters);
	if(!empty($api_response)){

		$response_json = array(
					"speech" => $api_response['displayText'],
					"displayText" => $api_response['displayText']);

		if(isset($api_response['clearContext']) && $api_response['clearContext'] === true)
			$is_clear_context = true;
	}

	$context_out = $gia_bot_api_obj->API_AI_Context_mapping($contexts,'payment', $is_clear_context);
}
else if($action == 'current-invoices')
{
	$api_response = $gia_bot_api_obj->get_current_invoices_details($parameters);
	if(!empty($api_response)){

		$response_json = array(
					"speech" => $api_response['displayText'],
					"displayText" => $api_response['displayText']);

		if(isset($api_response['clearContext']) && $api_response['clearContext'] === true)
			$is_clear_context = true;
	}

	$context_out = $gia_bot_api_obj->API_AI_Context_mapping($contexts,'current-invoice', $is_clear_context);
}
else if($action == 'past-invoices')
{
	$api_response = $gia_bot_api_obj->get_past_invoices_details($parameters);
	if(!empty($api_response)){

		$response_json = array(
					"speech" => $api_response['displayText'],
					"displayText" => $api_response['displayText']);

		if(isset($api_response['clearContext']) && $api_response['clearContext'] === true)
			$is_clear_context = true;
	}

	$context_out = $gia_bot_api_obj->API_AI_Context_mapping($contexts,'past-invoice', $is_clear_context);
}
else if($action == 'dispute-invoices')
{
	$api_response = $gia_bot_api_obj->get_dispute_invoices_details($parameters);
	if(!empty($api_response)){

		$response_json = array(
					"speech" => $api_response['displayText'],
					"displayText" => $api_response['displayText']);

		if(isset($api_response['clearContext']) && $api_response['clearContext'] === true)
			$is_clear_context = true;
	}

	$context_out = $gia_bot_api_obj->API_AI_Context_mapping($contexts,'dispute-invoice', $is_clear_context);
}
else if($action == 'ptp-invoices')
{
	$api_response = $gia_bot_api_obj->get_ptp_invoices_details($parameters);
	if(!empty($api_response)){

		$response_json = array(
					"speech" => $api_response['displayText'],
					"displayText" => $api_response['displayText']);

		if(isset($api_response['clearContext']) && $api_response['clearContext'] === true)
			$is_clear_context = true;
	}

	$context_out = $gia_bot_api_obj->API_AI_Context_mapping($contexts,'ptp-invoice', $is_clear_context);
}









if(empty($response_json))
{
	$response_json = array(
						"speech" => "My apologies, I don't understand.",
						"displayText" => "My apologies, I don't understand.");
}

if(!empty($context_out))
	$response_json['contextOut'] = $context_out;

$response_json['request'] = $request;
if(isset($api_response['data']))
	$response_json['data'] = $api_response['data'];

echo json_encode($response_json);
?>