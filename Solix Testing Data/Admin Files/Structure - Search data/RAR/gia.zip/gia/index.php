<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Chat bot</title>
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500" rel="stylesheet">
<link href="new-style.css" rel="stylesheet" type="text/css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="js/jquery.nicescroll.min.js"></script>
<script type="text/javascript">
    
    var  sessionId = "<?php echo rand();?>";
</script>
<script src="js/gia-bot.js"></script>

</head>

<body>

<div class="Chat_bot_div">
<div class="Chat_bot"  id="myDIV" style="display: none;">
  <div class="Gia_hd">
    <div class="GIA_logo"><img src="logo.png" width="300" alt="GIA logo"></div>
    <div class="close" onclick="myFunction()"><img src="close.png" width="27" height="16" alt="Close"></div>
    <div class="cl"></div>
  </div>
  <div class="intro"><img src="gia-intro.png" width="400" alt="intro logo">
    <p>I am GIA, Emagia.com powered Digital Finance Assistant. At your service!</p>
  </div>
  <div class="GIA_Chat">
    <ul>
      <li class="GIA_Chat loader" style="display: none;" class=""><p>typing...</p></li>

      <div class="cl"></div>
    </ul>
    <div class="cl"></div>
  </div>
  <div class="text_area">
      <textarea name="message" id="chat-input" placeholder="Type a message" required></textarea>
    <div class="voice"><a href="#" title="Search by voice"><img src="type-button.png" width="44" alt="Voice"></a></div>
   <div class="cl"></div>
    </div>
</div>
  <div class="Gia_avatar" onclick="myFunction()"><div class="avatar_Img"></div>
  
  <span class="tooltiptext">Hey, I’m ready to help you!</span>
  </div>
  </div>



</body>
</html>
