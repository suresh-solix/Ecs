function myFunction() {
    var x = document.getElementById('myDIV');
    if (x.style.display === 'none')
    {
        x.style.display = 'block';

    } else {
        x.style.display = 'none';
    }
}

var accessToken = "";
var baseUrl = "";
var firstMessage=1;

var firstMessage=1;


$(document).ready(function() {

    $.getJSON(settingsFile, function(json) {
        console.log(json); // this will show the info it in firebug console
        console.log(json.akey)
        console.log(json.bot_url)

        accessToken = json.akey;
        baseUrl = json.bot_url;
    });


    $("#chat-input").keypress(function(event) {
        if (event.which == 13 && $("#chat-input").val().trim() != '') {

            console.log("val: "+$("#chat-input").val());
            event.preventDefault();
            var text = $("#chat-input").val();
            insertChat("me", text, text, true, 0);

            if(firstMessage == 1)
            {
                $("div.GIA_Chat ul").css('height', eval($(".intro").height()+50));
                $(".intro").hide();
            }

            firstMessage=0;
            $(this).val('');
            setTimeout(send(text), 1000)
            
        }
        else
        {
            if($("#chat-input").val().trim() == '')
                $("#chat-input").val('');
        }
    });
    $("#rec").click(function(event) {
        switchRecognition();
    });

    $s-jQuery.noConflict();
    $s("div.GIA_Chat ul").niceScroll(); // First scrollable DIV
});

var recognition;

function startRecognition() {
    recognition = new webkitSpeechRecognition();
    recognition.onstart = function(event) {
        updateRec();
    };
    recognition.onresult = function(event) {
        var text = "";
        for (var i = event.resultIndex; i < event.results.length; ++i) {
            text += event.results[i][0].transcript;
        }
        
        setInput(text);
        stopRecognition();
    };
    recognition.onend = function() {
        stopRecognition();
    };
    recognition.lang = "en-US";
    recognition.start();
}

function stopRecognition() {
    if (recognition) {
        recognition.stop();
        recognition = null;
    }
    updateRec();
}

function switchRecognition() {
    if (recognition) {
        stopRecognition();
    } else {
        startRecognition();
    }
}

function setInput(text) {
    insertChat("me", text, text);
    $("#chat-input").val('');
    send(text);
}

function updateRec() {
    if(recognition)
    {
        $("#chat-input").attr("placeholder", "Listening...");
    }
    else
    {
        $("#chat-input").attr("placeholder", "");
    }
    
    $("#rec").css("color","#330066");
}

function send(text) {
        
    $.ajax({
        type: "POST",
        url: baseUrl,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        headers: {
            "Authorization": "Bearer " + accessToken
        },
        data: JSON.stringify({ query: text, sessionId: sessionId, akey:accessToken }),

        success: function(data) {
            //console.log(data)

            if(typeof data.reply_text !== typeof undefined)
            {
                var response_text = data.reply_text.replace(/(\r\n|\n|\r)/gm, "\n");
                var response_text = data.reply_text.replace(/(\\n)/gm, "\n");

                var ks = response_text.split("\n");
                //var ks = data.reply_text.match(/\n/g)
                //console.log(ks);
                //console.log(ks.length);
                if(ks.length <=1 )
                  var ks = response_text.replace(/(\r\n|\n|\r)/gm, "\n").split("\n");

                //console.log(ks);
                //console.log(ks.length);

                if(ks.length >1 )
                {
                    isLoaderDisplay=true;
                    isTimer=1000;
                }
                else
                {
                    isLoaderDisplay=false;
                    isTimer=1000;
                }

                $.each(ks, function(i,v)
                {
                    if(ks.length >1)
                    {
                        if(i == eval(ks.length - 1))
                            isLoaderDisplay=false;
                        else
                            isLoaderDisplay=true;

                        if(i==0)
                            isTimer=0;
                        else
                            isTimer=2000;
                    }

                    //console.log('iterator '+i+': isLoaderDisplay-'+isLoaderDisplay+', Timer-'+isTimer);

                    var speechText = v;

                    if(typeof data.data !== typeof undefined && typeof data.data.Image !== typeof undefined)
                    {
                        setTimeout(setResponse(data.data.Image+v,speechText,isLoaderDisplay,isTimer),500); 
                    }
                    else
                    {
                        setTimeout(setResponse(v,speechText,isLoaderDisplay,isTimer),500);                    
                    }
                });
            }
            else if(typeof data.data !== typeof undefined && typeof data.data.Image !== typeof undefined)
                setResponse(data.data.Image,false);
            else
                setResponse("My apologies, I don't understand.","My apologies, I don't understand.");
        },
        error: function() {
            setResponse("Internal Server Error","Internal Server Error");
        }
    });            
}

function setResponse(val, speechText, isloader=false, timeDelay=0) {
   
    if('speechSynthesis' in window)
    {
        var speechText=speechText.replace(/<[^>]+>/g, ', ');
        var speechText=speechText.replace(/INV#/g, 'Invoice Number ');
        var speechText=speechText.replace(/\|/g, ', ');

        var speechText=speechText.replace('Gia', 'JIYA')
        var speechText=speechText.replace('GIA', 'JIYA')
        var speechText=speechText.toLowerCase();
    }

    if(val != '')
        insertChat("bot", val, speechText, isloader, timeDelay);
    else
        insertChat("bot", "My apologies, I don't understand.", "My apologies, I don't understand." ,false, timeDelay);
}

function formatAMPM(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0'+minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
}            

//-- No use time. It is a javaScript effect.
function insertChat(who, text, speechText, isLoader = false, time = 1000){
    var control = "";
    var date = formatAMPM(new Date());
    
    if (who == "me")
    {
        control = '<li>' +
                      '<span>'+ text +'</span>' +
                    '</li>';                       
    }
    else
    {
        control = '<li class="GIA_Chat">' +
                      '<span>'+text+'</span>' +
                  '</li>';
    }

    setTimeout(
        function(){

            $(".GIA_Chat ul").append(control).fadeIn('slow', function(){
                $(".GIA_Chat ul").append($('div.GIA_Chat .loader'))

                if (isLoader == true)
                    $("div.GIA_Chat .loader").show();
                else
                    $("div.GIA_Chat .loader").hide();

                $("div.GIA_Chat ul").animate({ scrollTop: ($('div.GIA_Chat ul')[0].scrollHeight - $('div.GIA_Chat ul').height())});

                if (who == "bot" && isLoader == false)
                    $("div.GIA_Chat .loader").hide();

                if('speechSynthesis' in window && who == "bot")
                {
                    var speech = new SpeechSynthesisUtterance(speechText);
                    speech.lang = 'en-US';

                    var voices = window.speechSynthesis.getVoices();
                    speech.voice = voices[3];

                    window.speechSynthesis.speak(speech);
                }
            });
        }, time);
}