function myFunction() {
    var x = document.getElementById('myDIV');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}

var accessToken = "eb3729b3bf6848039e0af1b89aa9aa70";
var baseUrl = "http://accelforce.com/gia/bar/gia-bot.php";

$(document).ready(function() {
    $("#chat-input").keypress(function(event) {
        if (event.which == 13 && $("#chat-input").val().trim() != '') {

            console.log("val: "+$("#chat-input").val());
            event.preventDefault();
            var text = $("#chat-input").val();
            insertChat("me", text);
            $(this).val('');
            send(text);                   
        }
        else
        {
            if($("#chat-input").val().trim() == '')
                $("#chat-input").val('');
        }
    });
    $("#rec").click(function(event) {
        switchRecognition();
    });

    $(".GIA_Chat ul").niceScroll(); // First scrollable DIV
});

var recognition;

function startRecognition() {
    recognition = new webkitSpeechRecognition();
    recognition.onstart = function(event) {
        updateRec();
    };
    recognition.onresult = function(event) {
        var text = "";
        for (var i = event.resultIndex; i < event.results.length; ++i) {
            text += event.results[i][0].transcript;
        }
        setInput(text);
        stopRecognition();
    };
    recognition.onend = function() {
        stopRecognition();
    };
    recognition.lang = "en-US";
    recognition.start();
}

function stopRecognition() {
    if (recognition) {
        recognition.stop();
        recognition = null;
    }
    updateRec();
}

function switchRecognition() {
    if (recognition) {
        stopRecognition();
    } else {
        startRecognition();
    }
}

function setInput(text) {
    /* $("#chat-input").val(text);
    event.preventDefault();
    var text = $("#chat-input").val(); */
    insertChat("me", text);
    $("#chat-input").val('');
    send(text);
}

function updateRec() {
    if(recognition)
    {
        $("#chat-input").attr("placeholder", "Listening...");
    }
    else
    {
        $("#chat-input").attr("placeholder", "");
    }
    
    $("#rec").css("color","#330066");
}

function send(text) {
    
    
    $.ajax({
        type: "POST",
        url: baseUrl,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        headers: {
            "Authorization": "Bearer " + accessToken
        },
        data: JSON.stringify({ query: text, sessionId: sessionId, akey:accessToken }),

        success: function(data) {
            console.log(data)

            if(typeof data.reply_text !== typeof undefined)
            {
                var response_text = data.reply_text.replace(/(\r\n|\n|\r)/gm, "\n");
                var response_text = data.reply_text.replace(/(\\n)/gm, "\n");

                var ks = response_text.split("\n");
                //var ks = data.reply_text.match(/\n/g)
                //console.log(ks);
                //console.log(ks.length);
                if(ks.length <=1 )
                  var ks = response_text.replace(/(\r\n|\n|\r)/gm, "\n").split("\n");

                //console.log(ks);
                //console.log(ks.length);

                $.each(ks, function(i,v){

                    var speechText = v;
                    if(typeof data.data !== typeof undefined && typeof data.data.Image !== typeof undefined)
                    {
                        setTimeout(setResponse(data.data.Image+v,speechText),10000); 
                    }
                    else
                        setTimeout(setResponse(v,speechText),10000); 
                });                
                
            }
            else if(typeof data.data !== typeof undefined && typeof data.data.Image !== typeof undefined)
                setResponse(data.data.Image);
            else
                setResponse("My apologies, I don't understand.","My apologies, I don't understand.");
        },
        error: function() {
            setResponse("Internal Server Error","Internal Server Error");
        }
    });            
}

function setResponse(val,speechText) {
           
    if(val != '')
        insertChat("bot", val);
    else
        insertChat("bot", "My apologies, I don't understand.");

    if('speechSynthesis' in window)
    {
        var voiceout=speechText.replace(/<[^>]+>/g, ', ');
        var voiceout=voiceout.replace(/INV#/g, 'Invoice Number ');
        var voiceout=voiceout.replace(/\|/g, ', ');

        var voiceout=voiceout.replace('Gia', 'JIYA')
        var voiceout=voiceout.replace('GIA', 'JIYA')

        //console.log(voiceout);
        var speech = new SpeechSynthesisUtterance(voiceout.toLowerCase());
        speech.lang = 'en-US';

        var voices = window.speechSynthesis.getVoices();
        speech.voice = voices[3];

        speech.pitch = 1.5;
        speech.voulme = 1

        window.speechSynthesis.speak(speech);
    }
    else
    {

    }
}

function formatAMPM(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0'+minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
}            

//-- No use time. It is a javaScript effect.
function insertChat(who, text, time = 0){
    var control = "";
    var date = formatAMPM(new Date());
    
    if (who == "me")
    {
        
        control = '<li>' +
                      '<p>'+ text +'</p>' +
                    '</li>';                    

        $(".loader").show();
    }
    else
    {
        control = '<li class="GIA_Chat">' +
                      '<p>'+text+'</p>' +
                  '</li>';
        $(".loader").hide();
    }
    setTimeout(
        function(){                        
            $("ul").append(control).fadeIn('slow');
            $("ul").append($('.loader'))
            $("ul").animate({ scrollTop: $('ul').prop("scrollHeight")}, 2000);
        }, time);
}